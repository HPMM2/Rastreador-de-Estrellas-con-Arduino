// -----------------------------------------------------------------------------
// Wokwi Custom Chip - GPS NEO-6M con coordenadas dinámicas simuladas
// Documentación y ejemplos: https://docs.wokwi.com/chips-api/getting-started
// 
// SPDX-License-Identifier: MIT
// Copyright 2023 EQUIPO 3
// -----------------------------------------------------------------------------

// Este código define un "chip personalizado" para Wokwi que emula un módulo GPS
// NEO-6M, generando coordenadas dinámicas (latitud/longitud) en formato NMEA.
// Se comunica mediante UART para enviar datos como lo haría un GPS real.

#include "wokwi-api.h"  // Librería principal del API de chips personalizados en Wokwi
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define SECOND 1000000 // Un segundo 

// -----------------------------------------------------------------------------
// ESTRUCTURA DE ESTADO DEL CHIP
// -----------------------------------------------------------------------------
typedef struct {
  uart_dev_t uart0;  // Dispositivo UART (salida del GPS simulado)
  uint32_t index;    // Contador de eventos o actualizaciones
  float lat, lon;    // Coordenadas actuales (latitud y longitud)
} chip_state_t;

// Prototipo de la función de evento del temporizador
static void chip_timer_event(void *user_data);

// -----------------------------------------------------------------------------
// INICIALIZACIÓN DEL CHIP (se ejecuta al iniciar la simulación en Wokwi)
// -----------------------------------------------------------------------------
void chip_init(void) {
  setvbuf(stdout, NULL, _IOLBF, 1024); // Configura el buffer de salida para logs

  // Reserva memoria dinámica para el estado del chip
  chip_state_t *chip = malloc(sizeof(chip_state_t));
  chip->index = 0; // Inicializa contador

  // Coordenadas iniciales
  chip->lat = 19.432608;
  chip->lon = -99.133209;

  // ---------------------------------------------------------------------------
  // CONFIGURACIÓN DEL PUERTO UART (simula salida TX de un módulo GPS real)
  // ---------------------------------------------------------------------------
  const uart_config_t uart_config = {
    .tx         = pin_init("TX", INPUT_PULLUP), // Pin TX del GPS
    .rx         = pin_init("RX", INPUT),        // Pin RX (no usado aquí)
    .baud_rate  = 9600,                         // Velocidad típica de NEO-6M
    .user_data  = chip,                         // Apunta al estado del chip
  };

  // Inicializa el UART con la configuración anterior
  chip->uart0 = uart_init(&uart_config);

  // ---------------------------------------------------------------------------
  // CONFIGURACIÓN DEL TEMPORIZADOR (para generar coordenadas periódicamente)
  // ---------------------------------------------------------------------------
  const timer_config_t timer_config = {
    .callback  = chip_timer_event,  // Función que se ejecuta cada intervalo
    .user_data = chip,              // Estado del chip como parámetro
  };

  // Crea e inicia el temporizador, llamando a chip_timer_event() cada segundo
  timer_t timer = timer_init(&timer_config);
  timer_start(timer, SECOND, true);

  // Mensaje de depuración
  printf("Dynamic GPS Chip initialized!\n");
}

// -----------------------------------------------------------------------------
// FUNCIÓN: decToNMEA
// Convierte coordenadas decimales a formato NMEA (DDMM.MMM)
// Ejemplo: 19.4326° -> "1925.956,N"
// -----------------------------------------------------------------------------
void decToNMEA(float val, char *buf, char ns_ew) {
  int deg = (int) fabs(val);              // Grados enteros
  float min = (fabs(val) - deg) * 60.0;   // Minutos decimales
  sprintf(buf, "%02d%06.3f,%c", deg, min, ns_ew); // Formato final NMEA
}

// -----------------------------------------------------------------------------
// FUNCIÓN DE EVENTO DEL TEMPORIZADOR
// Se ejecuta cada segundo: actualiza las coordenadas y genera tramas NMEA
// -----------------------------------------------------------------------------
void chip_timer_event(void *user_data) {
  chip_state_t *chip = (chip_state_t*) user_data;
  chip->lat += ((rand() % 100) - 50) * 0.00001; // Variación en latitud
  chip->lon += ((rand() % 100) - 50) * 0.00001; // Variación en longitud

  // ---------------------------------------------------------------------------
  // Convierte coordenadas a formato NMEA
  // ---------------------------------------------------------------------------
  char latStr[16], lonStr[16];
  decToNMEA(chip->lat, latStr, (chip->lat >= 0) ? 'N' : 'S');
  decToNMEA(chip->lon, lonStr, (chip->lon >= 0) ? 'E' : 'W');

  // ---------------------------------------------------------------------------
  // Genera tramas NMEA tipo GPGGA y GPRMC (las más comunes en GPS)
  // ---------------------------------------------------------------------------
  char gpgga[128], gprmc[128];
  
  // $GPGGA = Fix de posición (altitud, satélites, precisión, etc.)
  sprintf(gpgga,
          "$GPGGA,123519,%s,%s,1,08,0.9,545.4,M,46.9,M,,*47\r\n",
          latStr, lonStr);

  // $GPRMC = Recomendado Mínimo (posición, velocidad, fecha, etc.)
  sprintf(gprmc,
          "$GPRMC,123519,A,%s,%s,0.0,0.0,291025,0.0,E*68\r\n",
          latStr, lonStr);

  // ---------------------------------------------------------------------------
  // Envía las tramas NMEA por UART al microcontrolador
  // ---------------------------------------------------------------------------
  uart_write(chip->uart0, (uint8_t*) gpgga, strlen(gpgga));
  uart_write(chip->uart0, (uint8_t*) gprmc, strlen(gprmc));
}
